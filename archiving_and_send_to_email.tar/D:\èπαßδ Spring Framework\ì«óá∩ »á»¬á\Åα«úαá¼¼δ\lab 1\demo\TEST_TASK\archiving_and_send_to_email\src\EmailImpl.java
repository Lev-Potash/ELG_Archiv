import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Properties;

public class EmailImpl {

    private static EmailImpl instance;

    public static EmailImpl getInstance() { // #3
        if(instance == null){		//если объект еще не создан
            instance = new EmailImpl();	//создать новый объект
        }
        return instance;		// вернуть ранее созданный объект
    }


    public void sendEmail(String filename) throws IOException, MessagingException {
        String to = "lev_potashnikov@rambler.ru";         // sender email
        String from = "lptash4@gmail.com";       // receiver email
        String host = "127.0.0.1";            // mail server host

        //Properties properties = System.getProperties();
        //properties.setProperty("mail.smtp.host", host);
        //properties.setProperty("smtp.gmail.com", host);
        Properties properties = new Properties();
        properties.load(Main.class/*.getClassLoader()*/.getResourceAsStream("mail.properties"));


        Session session = Session.getDefaultInstance(properties); // default session

        //try {
        MimeMessage message = new MimeMessage(session); // email message

        message.setFrom(new InternetAddress(from)); // setting header fields

        message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

        message.setSubject("Test Mail from Java Program"); // subject line

        // actual mail body
        message.setText("You can send mail from Java program by using mail API, but you need" +
                "couple of more JAR files e.g. smtp.jar and activation.jar");

        // Part two is attachment
        //messageBodyPart = new MimeBodyPart();
        //String filename = "archiving_and_send_to_email.tar";
        DataSource source = new FileDataSource(filename);
        /*messageBodyPart.setDataHandler(new DataHandler(source));
        messageBodyPart.setFileName(filename);
        multipart.addBodyPart(messageBodyPart);*/

        message.setDataHandler(new DataHandler(source));
        message.setFileName(filename);
        //multipart.addBodyPart(messageBodyPart);



        // Send message
        Transport tr = session.getTransport();
        tr.connect(null, "Leva@1234");
        tr.sendMessage(message, message.getAllRecipients());
        tr.close();
        System.out.println("Email Sent successfully....");
        //} catch (MessagingException mex){ mex.printStackTrace(); }

    }
}
